<html lang="en">
  <head>
   <title>Signin for doctor</title>
 <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="../css/signin.css" rel="stylesheet" type="text/css" />
  </head>

<body style="background-image:url('image/dctr.jpg')">
	<div class="container">
	<div class="col-md-4 col-md-offset-2" style="margin-top:100px;height:600px;width:500px">
		
		<form class="form-signin" action="final1.php" method="post">
			<fieldset>
				<h2 class="form-signin-heading" style="margin-top:50px;">Please select any place</h2>
				<select name="place_id" style="margin-top:50px;">
								<?php
									include('../include/dbcon.php');
									$b_q = "select * from tbl_scanner";
									$b_r = mysqli_query($con,$b_q);
									while($b_row = mysqli_fetch_array($b_r))
									{
											echo "<option value='" .$b_row['place_id'] ."'>" .$b_row['place_name'] ."</option>";
									}
										
								?>
								
								
							</select>
				<button class="btn btn-lg btn-primary btn-block"  style="margin-top:50px;" type="submit" name="submit">Sign in</button><br>
			</fieldset>
      </form>
	</div> <!-- /container -->
  </body>
</html>