<?php
//error_reporting(E_ALL);
$con = mysqli_connect('localhost','root','','db_scanner');
$place_id='2';
//select database
if(!$con)
{
	die('dastabase is not selected');
}

$q ="select * from tbl_place where place_id =$place_id";
//select hotel ids string for explode
$r = mysqli_query($con,$q);
$row = mysqli_fetch_array($r);

$hotel = explode(',',$row[2]);

for($i=0;$i<count($hotel);$i++)
{
	$val =$hotel[$i];
	$sql = "select * from tbl_hotel where hotel_id=$val";
		$run = mysqli_query($con,$sql);
		$row = mysqli_fetch_array($run);
		{
			echo "hotel by name is:" . $row['hotel_name'] ."</br>";
?>
			<img src='<?php echo $row['path']; ?>' height='100px' width='100px'/>
<?php
		}
	}


?>
