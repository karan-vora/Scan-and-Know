<?php
//error_reporting(E_ALL);
$con = mysqli_connect('localhost','root','','db_scanner');

//select database
if(!$con)
{
	die('dastabase is not selected');
}
?>

